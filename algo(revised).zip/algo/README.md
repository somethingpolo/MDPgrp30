# Algorithm



## Install Project Dependencies
```bash
pip install -r requirements.txt
```

## Run Project
```bash
python main.py
```

### Notes
- Use it mpd env

### Task
- Watch the video
- NTULearn link about the algo
- NO1 Repo
